import numpy as np, pandas as pd, datetime as dt
from datetime import date, timedelta
rng=np.random.default_rng(2026)
HOJE=date(2026,11,16)
MESES=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']

# ======================= REAIS (públicos) =======================
mensal=[2781,3410,13437,52400,74556,69530,63856,73123,76987,57349,10021,2811]
tot=sum(mensal)
r1=pd.DataFrame({'ano':2025,'mes':range(1,13),'mes_nome':MESES,'peregrinos_total':mensal})
r1['pct_do_ano']=(r1.peregrinos_total/tot*100).round(2)
r1['fonte']='Oficina del Peregrino (registro de Compostelas), via ElCaminoParaLatinos (2026)'
r1.to_csv('real_oficina_peregrino_2025_mensal.csv',index=False,encoding='utf-8-sig')

r2=pd.DataFrame([
 ['Português (central)',3293,39.17,'ElCaminoParaLatinos (2026), dados da Oficina del Peregrino'],
 ['Francês',2945,35.03,'ElCaminoParaLatinos (2026), dados da Oficina del Peregrino'],
 ['Português da Costa',1220,14.51,'ElCaminoParaLatinos (2026), dados da Oficina del Peregrino'],
 ['Português (central)',3317,None,'Apresentação T4F Performance (2026), Oficina del Peregrino, ano completo'],
 ['Francês',2968,None,'Apresentação T4F Performance (2026), Oficina del Peregrino, ano completo'],
 ['Português da Costa',1225,None,'Apresentação T4F Performance (2026), Oficina del Peregrino, ano completo'],
 ['Demais caminhos',957,None,'Apresentação T4F Performance (2026), Oficina del Peregrino, ano completo'],
],columns=['caminho','chegadas_brasileiros_2025','pct_informado','fonte'])
r2.insert(0,'ano',2025)
r2.to_csv('real_oficina_peregrino_2025_brasil_por_caminho.csv',index=False,encoding='utf-8-sig')

clima=pd.DataFrame({'mes':range(1,13),'mes_nome':MESES,
 'temp_min_c':[4.1,3.9,5.2,6.3,8.7,11.2,12.9,13.3,11.8,9.6,6.5,4.9],
 'temp_max_c':[11.5,12.7,15.3,16.7,19.6,22.6,24.7,25.0,22.9,18.6,14.1,12.2],
 'temp_media_c':[7.8,8.3,10.3,11.5,14.2,16.9,18.8,19.2,17.4,14.1,10.3,8.5],
 'chuva_mm':[260,225,145,140,145,80,40,55,125,195,200,280],
 'dias_de_chuva':[16,14,13,14,14,8,5,5,9,13,14,16],
 'horas_sol_dia':[3,4,5,5.5,6,7.5,8,7.5,6,4.5,3,2.5],
 'umidade_pct':[87,82,78,78,78,77,77,77,79,84,88,87]})
clima.insert(0,'local','Santiago de Compostela (normais 1991-2020)')
clima['fonte']='Climates to Travel, com base em normais climatológicas 1991-2020'
clima.to_csv('real_clima_santiago_normais_1991_2020.csv',index=False,encoding='utf-8-sig')

def easter(y):
    a=y%19;b=y//100;c=y%100;d=b//4;e=b%4;f=(b+8)//25;g=(b-f+1)//3;h=(19*a+b-d-g+15)%30
    i=c//4;k=c%4;l=(32+2*e+2*i-h-k)%7;m=(a+11*h+22*l)//451
    mo=(h+l-7*m+114)//31;da=((h+l-7*m+114)%31)+1
    return date(y,mo,da)
fer=[]
for y in (2026,2027):
    E=easter(y); cc=E+timedelta(days=60); carn=E-timedelta(days=47)
    es=[(date(y,1,1),'Año Nuevo'),(date(y,1,6),'Epifanía'),(E-timedelta(days=3),'Jueves Santo'),(E-timedelta(days=2),'Viernes Santo'),
        (date(y,5,1),'Día del Trabajo'),(date(y,5,17),'Día das Letras Galegas'),(date(y,7,25),'Santiago Apóstol / Día Nacional de Galicia'),
        (date(y,8,15),'Asunción'),(date(y,10,12),'Fiesta Nacional'),(date(y,11,1),'Todos los Santos'),(date(y,12,6),'Día de la Constitución'),
        (date(y,12,8),'Inmaculada'),(date(y,12,25),'Navidad')]
    pt=[(date(y,1,1),'Ano Novo'),(E-timedelta(days=2),'Sexta-feira Santa'),(E,'Páscoa'),(date(y,4,25),'Dia da Liberdade'),(date(y,5,1),'Dia do Trabalhador'),
        (cc,'Corpo de Deus'),(date(y,6,10),'Dia de Portugal'),(date(y,8,15),'Assunção'),(date(y,10,5),'Implantação da República'),
        (date(y,11,1),'Todos os Santos'),(date(y,12,1),'Restauração da Independência'),(date(y,12,8),'Imaculada Conceição'),(date(y,12,25),'Natal')]
    br=[(date(y,1,1),'Confraternização Universal'),(carn,'Carnaval (terça-feira)'),(E-timedelta(days=2),'Sexta-feira Santa'),(date(y,4,21),'Tiradentes'),
        (date(y,5,1),'Dia do Trabalho'),(cc,'Corpus Christi'),(date(y,9,7),'Independência'),(date(y,10,12),'Nossa Senhora Aparecida'),
        (date(y,11,2),'Finados'),(date(y,11,15),'Proclamação da República'),(date(y,11,20),'Consciência Negra'),(date(y,12,25),'Natal')]
    for pais,lst in (('Espanha (Galiza)',es),('Portugal',pt),('Brasil',br)):
        for d,n in lst: fer.append([pais,d,n,['seg','ter','qua','qui','sex','sáb','dom'][d.weekday()]])
f=pd.DataFrame(fer,columns=['pais','data','feriado','dia_semana'])
f['ano_santo_xacobeo']=(pd.to_datetime(f.data).dt.year==2027)
f['observacao']='Calculado por regra de calendário; conferir em calendário oficial antes de uso operacional'
f.sort_values(['data','pais']).to_csv('real_feriados_2026_2027.csv',index=False,encoding='utf-8-sig')

# ======================= SINTÉTICOS (gerados por IA) =======================
partidas={ # ponto: (caminho,  peso, preco_standard_eur, dias)
 'Sarria':('Francês',.225,1100,7),'Astorga':('Francês',.07,2000,12),'SJPP':('Francês',.10,4500,33),
 'Lisboa':('Português central',.12,3900,27),'Porto (central)':('Português central',.17,1800,11),'Tui/Valença':('Português central',.15,1000,6),
 'Porto litoral':('Português da Costa',.163,2000,12)}
pts=list(partidas); pw=np.array([partidas[p][1] for p in pts]); pw/=pw.sum()
fat={'Econômico':0.78,'Standard':1.0,'Superior':1450/1100}
sz=np.array(mensal,float); sz/=sz.sum()

N=1000
# datas de viagem: mar/2026 a out/2027
cands=pd.date_range('2026-03-01','2027-10-31')
wd=np.array([sz[d.month-1]*(1.12 if d.year==2027 else 1.0) for d in cands]); wd/=wd.sum()
viagem=rng.choice(cands,size=N,p=wd)
antec=np.clip(rng.lognormal(4.5,.55,N),14,330).astype(int)
compra=pd.to_datetime(viagem)-pd.to_timedelta(antec,unit='D')
ok=compra<=pd.Timestamp(HOJE)
viagem=viagem[ok];antec=antec[ok];compra=compra[ok];n=len(viagem)
ponto=rng.choice(pts,size=n,p=pw)
cat=rng.choice(list(fat),size=n,p=[.25,.50,.25])
pax=rng.choice([1,2,3,4],size=n,p=[.22,.58,.12,.08])
preco_pp=np.array([partidas[p][2]*fat[c] for p,c in zip(ponto,cat)])*rng.normal(1,.02,n)
valor=(preco_pp*pax).round(2)
pay=rng.choice(['Cartão de crédito','Pix','Boleto','Transferência internacional'],size=n,p=[.50,.30,.10,.10])
pcanc=np.where(antec>150,.13,.07)
canc=rng.random(n)<pcanc
status=np.where(canc,'cancelada',np.where(pd.to_datetime(viagem)<=pd.Timestamp(HOJE),'realizada','confirmada'))
# clientes
ncli=int(n*.9); cid=rng.integers(1,ncli+1,size=n)
ufs=['SP','RJ','MG','RS','PR','SC','DF','BA','Outras']; up=[.34,.12,.10,.08,.08,.06,.06,.04,.12]
cli=pd.DataFrame({'id_cliente':np.arange(1,ncli+1),
 'faixa_etaria':rng.choice(['18-29','30-44','45-59','60+'],size=ncli,p=[.10,.30,.38,.22]),
 'nacionalidade':'Brasil','uf_residencia':rng.choice(ufs,size=ncli,p=up),
 'canal_aquisicao':rng.choice(['Instagram','Indicação','Google','WhatsApp','E-mail/Newsletter'],size=ncli,p=[.28,.30,.20,.14,.08]),
 'experiencia_previa_camino':rng.choice(['Não','Sim'],size=ncli,p=[.78,.22])})
cli.to_csv('sintetico_clientes.csv',index=False,encoding='utf-8-sig')
res=pd.DataFrame({'id_reserva':np.arange(1,n+1),'id_cliente':cid,'data_compra':pd.to_datetime(compra).date,
 'data_viagem':pd.to_datetime(viagem).date,'antecedencia_dias':antec,'ponto_partida':ponto,
 'caminho':[partidas[p][0] for p in ponto],'duracao_dias':[partidas[p][3] for p in ponto],'categoria_hospedagem':cat,
 'n_viajantes':pax,'valor_eur':valor,'forma_pagamento':pay,'status':status})
res['mes_viagem']=pd.to_datetime(res.data_viagem).dt.month
res.sort_values('data_compra').reset_index(drop=True).to_csv('sintetico_reservas.csv',index=False,encoding='utf-8-sig')

# ocupação por etapa/data/categoria (Sarria -> Santiago)
etapas=['Sarria','Portomarín','Palas de Rei','Arzúa','O Pedrouzo','Santiago']
capb={'Econômico':10,'Standard':8,'Superior':4}
dias=list(pd.date_range('2026-11-01','2026-12-15'))+list(pd.date_range('2027-04-01','2027-10-31'))
rows=[]
for d in dias:
    base=sz[d.month-1]/sz.max()   # 0..1 sazonalidade oficial
    for e in etapas:
        for c in capb:
            cap=int(max(2,round(capb[c]*rng.normal(1,.12))))
            taxa=np.clip(0.12+0.62*base+rng.normal(0,.11)+(0.05 if e in('Sarria','Santiago') else 0),0.05,1.5)
            com=int(round(cap*taxa))
            rows.append([d.date(),e,c,cap,com])
oc=pd.DataFrame(rows,columns=['data','etapa','categoria','capacidade_vagas_noite','comprometidas_vagas_noite'])
mask=(oc.data==date(2026,11,14))&(oc.etapa=='Portomarín')&(oc.categoria=='Superior')
oc.loc[mask,['capacidade_vagas_noite','comprometidas_vagas_noite']]=[2,3]
oc['taxa_ocupacao_pct']=(oc.comprometidas_vagas_noite/oc.capacidade_vagas_noite*100).round(1)
oc['semaforo']=np.where(oc.taxa_ocupacao_pct>85,'Crítico',np.where(oc.taxa_ocupacao_pct>=75,'Atenção','Favorável'))
oc['faltam_vagas_noite']=(oc.comprometidas_vagas_noite-oc.capacidade_vagas_noite).clip(lower=0)
oc.to_csv('sintetico_ocupacao_hospedagens.csv',index=False,encoding='utf-8-sig')

# NPS: 300 respostas -> 234 promotores, 48 neutros, 18 detratores (NPS = 72)
real=res[res.status=='realizada']
amostra=real.sample(300,random_state=7).reset_index(drop=True)
notas=np.array([rng.choice([9,10],p=[.3,.7]) for _ in range(234)]+[rng.choice([7,8]) for _ in range(48)]+[rng.choice([3,4,5,6]) for _ in range(18)])
rng.shuffle(notas)
tema=np.where(notas<=6,rng.choice(['Hospedagem','Bagagem','Comunicação','Guia/rota'],size=300,p=[.35,.30,.20,.15]),'')
fb=pd.DataFrame({'id_feedback':np.arange(1,301),'id_reserva':amostra.id_reserva,'data_resposta':pd.to_datetime(amostra.data_viagem)+pd.to_timedelta(amostra.duracao_dias+2,unit='D'),
 'ponto_partida':amostra.ponto_partida,'categoria_hospedagem':amostra.categoria_hospedagem,'nota_0_10':notas,
 'classe':np.where(notas>=9,'Promotor',np.where(notas>=7,'Neutro','Detrator')),'tema_principal_critica':tema})
fb['data_resposta']=fb.data_resposta.dt.date
fb.to_csv('sintetico_feedbacks_nps.csv',index=False,encoding='utf-8-sig')
print('NPS',((fb.classe=='Promotor').mean()-(fb.classe=='Detrator').mean())*100)

# financeiro mensal (formato do dashboard demonstrativo; só junho é valor citado na apresentação)
rec={3:41.2,4:67.5,5:88.9,6:99.8,8:94.3,9:108.6,10:79.4}
fin=[]
for m,r in rec.items():
    custo=74.9 if m==6 else round(r*rng.uniform(.735,.77),1)
    fin.append([2026,m,MESES[m-1],round(r*1000),round(custo*1000),round((r-custo)*1000)])
fin=pd.DataFrame(fin,columns=['ano','mes','mes_nome','receita_contratada_brl','custos_operacionais_brl','contribuicao_brl'])
fin['margem_contribuicao_pct']=(fin.contribuicao_brl/fin.receita_contratada_brl*100).round(1)
fin['observacao']=np.where(fin.mes==6,'Valor citado na apresentação (R$ 99,8 mil / 74,9 mil / 24,9 mil)','Valor sintético ilustrativo')
fin.to_csv('sintetico_financeiro_mensal.csv',index=False,encoding='utf-8-sig')

print(len(res),res.status.value_counts().to_dict(),len(cli),len(oc),oc.semaforo.value_counts().to_dict())
print(res.groupby('caminho').size()/len(res))
print(oc[mask])
print(fin)
