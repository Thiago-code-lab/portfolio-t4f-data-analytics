# Bases de dados do projeto T4F Performance (Tour4Friends)

Arquivos CSV (UTF-8, separador vírgula). Prefixo `real_` = dados reais/públicos; prefixo `sintetico_` = dados gerados por IA para prototipagem.
A base "Real (empresa)" (tabela de vendas da Tour4Friends) não está incluída, conforme combinado.

## Reais (públicos)
| Arquivo | Conteúdo | Fonte |
|---|---|---|
| real_oficina_peregrino_2025_mensal.csv | Peregrinos (todas as nacionalidades) que solicitaram a Compostela, por mês, 2025 | Oficina del Peregrino, conforme publicado por ElCaminoParaLatinos (2026) |
| real_oficina_peregrino_2025_brasil_por_caminho.csv | Chegadas de brasileiros por caminho, 2025 | Duas fontes lado a lado: ElCaminoParaLatinos e a apresentação T4F Performance |
| real_clima_santiago_normais_1991_2020.csv | Temperatura, chuva, sol e umidade médias mensais | Climates to Travel (normais 1991-2020) |
| real_feriados_2026_2027.csv | Feriados da Espanha (Galiza), Portugal e Brasil | Calculado por regra de calendário (Páscoa etc.); conferir em calendário oficial |

Atenção: os números de brasileiros por caminho diferem levemente entre as duas fontes (ex.: Português 3.293 x 3.317; Francês 2.945 x 2.968; Costa 1.220 x 1.225),
provavelmente por data de extração. O texto do documento usa os números da apresentação. Registre a data de consulta e cite a Oficina del Peregrino
(https://oficinadelperegrino.com/estadisticas/) como fonte primária.
A fonte da série mensal é um site de terceiros que cita a Oficina; confira no site oficial antes da entrega.

## Sintéticos (gerados por IA, não são dados reais da Tour4Friends)
| Arquivo | Linhas | Conteúdo |
|---|---|---|
| sintetico_clientes.csv | 422 | Perfil dos clientes (faixa etária, UF, canal de aquisição) |
| sintetico_reservas.csv | 469 | Reservas 2026-2027: partida, caminho, categoria, viajantes, valor em euros, status (realizada, confirmada, cancelada) |
| sintetico_ocupacao_hospedagens.csv | 4.662 | Capacidade x vagas-noite comprometidas por etapa (Sarria a Santiago), data e categoria, com semáforo (<75% Favorável, 75-85% Atenção, >85% Crítico) |
| sintetico_feedbacks_nps.csv | 300 | Notas 0-10 (78% promotores, 16% neutros, 6% detratores: NPS = 72) |
| sintetico_financeiro_mensal.csv | 7 | Receita, custo e contribuição por mês (só junho/2026 vem da apresentação) |

Premissas do gerador (`gen_bases.py`, semente 2026): a sazonalidade segue os dados mensais reais da Oficina; a distribuição por caminho segue a proporção
60,5% português / 39,5% francês do insight; preços: apenas Sarria Standard (EUR 1.100) e Superior (EUR 1.450) vêm da tabela de vendas da apresentação,
os demais preços e o fator do Econômico (0,78) são inventados. A categoria Premium do exemplo de Portomarín foi mapeada para Superior (capacidade 2, comprometidas 3, em 14/11/2026).

## Relacionamentos
clientes.id_cliente 1-N reservas.id_cliente; reservas.id_reserva 1-N feedbacks_nps.id_reserva. Ocupação e financeiro são independentes (sem chave).
